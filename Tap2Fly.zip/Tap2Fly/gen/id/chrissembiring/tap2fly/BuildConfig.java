/** Automatically generated file. DO NOT MODIFY */
package id.chrissembiring.tap2fly;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}